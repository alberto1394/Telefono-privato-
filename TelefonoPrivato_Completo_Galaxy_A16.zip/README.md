# Telefono Privato 2.0

Progetto Android per Samsung Galaxy A16 (Android 8.0+; compilazione con SDK 35).

## Funzioni
- Primo avvio: creazione di un PIN personale da 4 a 8 cifre.
- Tastierino numerico con tasto verde.
- PIN verificato con PBKDF2-HMAC-SHA256 e salt casuale.
- Foto, video e documenti importati nella cassaforte vengono cifrati con AES-256-GCM tramite chiave generata e custodita in Android Keystore.
- Esportazione esplicita dei file e cancellazione dei file cifrati.
- Blocco quando l'app passa in background (escluso il selettore file).

## Limiti
- L'importazione crea una copia cifrata; NON elimina l'originale dalla Galleria/Download.
- Non può nascondere, clonare, trasferire o inglobare altre app installate.
- Non può aprire o controllare direttamente Area Personale Samsung; l'utente può continuare a usarla separatamente.
- Non è un'app di sistema e l'icona non può essere resa identica in modo garantito a quella Telefono Samsung.
- Se si disinstalla l'app o si cancellano i suoi dati, la chiave Keystore può essere eliminata e i file cifrati potrebbero diventare irrecuperabili. Esportare copie sicure prima di disinstallare o ripristinare il telefono.
- Non protegge da un dispositivo già compromesso/rootato o da chi conosce il PIN dell'app e ha accesso al telefono sbloccato.

## Compilazione
Caricare il contenuto di questo archivio nel livello principale del repository GitHub (non caricare solo lo ZIP). La cartella `.github/workflows` deve rimanere al livello principale. Poi aprire Actions e avviare "Crea APK Android". L'APK sarà disponibile come artifact `TelefonoPrivato-APK`.
