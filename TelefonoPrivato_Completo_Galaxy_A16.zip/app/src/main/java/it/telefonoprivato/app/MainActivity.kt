package it.telefonoprivato.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

private val Green = Color(0xFF16A765)
private val Dark = Color(0xFF202124)

class MainActivity : ComponentActivity() {
    private var pickerInProgress = false
    private var lockCallback: (() -> Unit)? = null

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && !pickerInProgress) lockCallback?.invoke()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.WHITE
        window.navigationBarColor = android.graphics.Color.WHITE
        setContent { TelefonoPrivatoApp(this, filesDir) { lockCallback = it } }
    }

    fun markPickerStarted() { pickerInProgress = true }
    fun markPickerFinished() { pickerInProgress = false }
}

@Composable
private fun TelefonoPrivatoApp(
    activity: MainActivity,
    privateDir: File,
    setLockCallback: ((() -> Unit) -> Unit)
) {
    var hasPin by remember { mutableStateOf(VaultSecurity.hasPin(activity)) }
    var unlocked by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var firstPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val vault = remember { File(privateDir, "vault") }

    SideEffect { setLockCallback { unlocked = false; pin = "" } }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        activity.markPickerFinished()
        if (uri != null) {
            runCatching {
                val name = VaultSecurity.displayName(activity.contentResolver, uri)
                VaultSecurity.encryptIntoVault(activity.contentResolver, uri, name, vault)
                refresh++
            }.onFailure { error = "Importazione non riuscita: ${it.localizedMessage ?: "errore"}" }
        }
    }
    var exportTarget by remember { mutableStateOf<File?>(null) }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        activity.markPickerFinished()
        val target = exportTarget
        if (uri != null && target != null) {
            runCatching {
                activity.contentResolver.openOutputStream(uri)?.use { VaultSecurity.export(target, it) }
                    ?: throw IllegalStateException("Impossibile creare il file")
            }.onFailure { error = "Esportazione non riuscita: ${it.localizedMessage ?: "errore"}" }
        }
        exportTarget = null
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Color.White, surface = Color.White)) {
        when {
            !hasPin -> PinSetupScreen(
                firstPin = firstPin,
                pin = pin,
                error = error,
                onPin = { pin = it; error = "" },
                onFirstPin = { firstPin = it; error = "" },
                onSave = {
                    if (firstPin.length !in 4..8 || pin.length !in 4..8) error = "Usa un PIN da 4 a 8 cifre."
                    else if (firstPin != pin) { error = "I due PIN non coincidono."; pin = "" }
                    else { VaultSecurity.setPin(activity, pin); hasPin = true; unlocked = true; pin = ""; firstPin = "" }
                }
            )
            !unlocked -> DialerScreen(
                pin = pin, error = error,
                onDigit = { if (pin.length < 8) { pin += it; error = "" } },
                onDelete = { if (pin.isNotEmpty()) pin = pin.dropLast(1) },
                onUnlock = {
                    if (VaultSecurity.verifyPin(activity, pin)) { unlocked = true; error = ""; pin = "" }
                    else { error = "PIN non corretto"; pin = "" }
                }
            )
            else -> VaultScreen(
                files = VaultSecurity.listNames(vault),
                error = error,
                onImport = { activity.markPickerStarted(); importPicker.launch(arrayOf("*/*")) },
                onExport = { file, name ->
                    exportTarget = file
                    activity.markPickerStarted()
                    exportPicker.launch(name)
                },
                onDelete = { file -> file.delete(); refresh++ },
                onLock = { unlocked = false; pin = "" },
                onChangePin = { oldPin, newPin ->
                    if (!VaultSecurity.verifyPin(activity, oldPin)) error = "PIN attuale non corretto"
                    else if (newPin.length !in 4..8) error = "Il nuovo PIN deve avere 4-8 cifre"
                    else { VaultSecurity.setPin(activity, newPin); error = "PIN modificato correttamente" }
                },
                refresh = refresh
            )
        }
    }
}

@Composable
private fun PinSetupScreen(
    firstPin: String, pin: String, error: String,
    onPin: (String) -> Unit, onFirstPin: (String) -> Unit, onSave: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Color.White).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(48.dp))
        Icon(Icons.Default.Lock, null, tint = Green, modifier = Modifier.size(52.dp))
        Text("Configura Telefono Privato", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Scegli un PIN personale da 4 a 8 cifre. Non sarà il PIN Samsung.", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        PinField("Crea PIN", firstPin, onFirstPin)
        Spacer(Modifier.height(12.dp))
        PinField("Conferma PIN", pin, onPin)
        if (error.isNotBlank()) Text(error, color = Color.Red)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Crea cassaforte") }
    }
}

@Composable
private fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { v -> if (v.length <= 8 && v.all(Char::isDigit)) onChange(v) },
        label = { Text(label) }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun DialerScreen(
    pin: String, error: String, onDigit: (String) -> Unit, onDelete: () -> Unit, onUnlock: () -> Unit
) {
    val keys = listOf("1","2","3","4","5","6","7","8","9","*","0","#")
    Column(Modifier.fillMaxSize().background(Color.White).padding(horizontal = 26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(44.dp))
        Icon(Icons.Default.Phone, null, tint = Green, modifier = Modifier.size(30.dp))
        Text("Telefono", color = Color.Gray, fontSize = 17.sp)
        Spacer(Modifier.weight(1f))
        Text(if (pin.isEmpty()) " " else "• ".repeat(pin.length), fontSize = 28.sp, color = Dark)
        if (error.isNotBlank()) Text(error, color = Color.Red, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        keys.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { key ->
                    Box(Modifier.size(76.dp).clickable { if (key.all(Char::isDigit)) onDigit(key) }, contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(key, fontSize = 29.sp, color = Dark)
                            Text(when (key) { "2"->"ABC";"3"->"DEF";"4"->"GHI";"5"->"JKL";"6"->"MNO";"7"->"PQRS";"8"->"TUV";"9"->"WXYZ";else->"" }, fontSize = 9.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.size(58.dp))
            Box(Modifier.size(62.dp).background(Green, CircleShape).clickable { onUnlock() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Phone, "Sblocca", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            Box(Modifier.size(58.dp).clickable { onDelete() }, contentAlignment = Alignment.Center) { Text("⌫", fontSize = 25.sp) }
        }
        Spacer(Modifier.weight(1f))
        Text("Preferiti     Recenti     Contatti", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun VaultScreen(
    files: List<Pair<File, String>>,
    error: String,
    onImport: () -> Unit,
    onExport: (File, String) -> Unit,
    onDelete: (File) -> Unit,
    onLock: () -> Unit,
    onChangePin: (String, String) -> Unit,
    refresh: Int
) {
    var showPinChange by remember { mutableStateOf(false) }
    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Folder, null, tint = Green, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(10.dp))
            Text("Cartella privata", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconButton(onClick = { showPinChange = !showPinChange }) { Icon(Icons.Default.Settings, "Impostazioni") }
            TextButton(onClick = onLock) { Text("Blocca") }
        }
        Text("File cifrati nella memoria privata dell'app. L'originale non viene eliminato.", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("＋  Importa foto, video o documenti") }
        if (showPinChange) {
            Spacer(Modifier.height(10.dp))
            PinField("PIN attuale", oldPin) { oldPin = it }
            PinField("Nuovo PIN", newPin) { newPin = it }
            Button(onClick = { onChangePin(oldPin, newPin); oldPin = ""; newPin = "" }) { Text("Salva nuovo PIN") }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFB3261E), fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        if (files.isEmpty()) Text("La cassaforte è vuota.", color = Color.Gray)
        else LazyColumn {
            items(files, key = { it.first.name }) { (file, name) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, modifier = Modifier.weight(1f), fontSize = 14.sp, maxLines = 2)
                    TextButton(onClick = { onExport(file, name) }) { Text("Esporta") }
                    IconButton(onClick = { onDelete(file) }) { Icon(Icons.Default.Delete, "Elimina") }
                }
                HorizontalDivider()
            }
        }
    }
}
