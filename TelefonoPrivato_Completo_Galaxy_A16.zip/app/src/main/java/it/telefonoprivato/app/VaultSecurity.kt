package it.telefonoprivato.app

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.*
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

object VaultSecurity {
    private const val PREFS = "vault_settings"
    private const val SALT = "pin_salt"
    private const val HASH = "pin_hash"
    private const val ITERATIONS = 160_000
    private const val KEY_ALIAS = "telefono_privato_vault_key"
    private const val NONCE_SIZE = 12

    fun hasPin(context: android.content.Context): Boolean =
        context.getSharedPreferences(PREFS, 0).contains(HASH)

    fun setPin(context: android.content.Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin, salt)
        context.getSharedPreferences(PREFS, 0).edit()
            .putString(SALT, android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP))
            .putString(HASH, android.util.Base64.encodeToString(hash, android.util.Base64.NO_WRAP))
            .apply()
    }

    fun verifyPin(context: android.content.Context, pin: String): Boolean {
        val prefs = context.getSharedPreferences(PREFS, 0)
        val saltText = prefs.getString(SALT, null) ?: return false
        val hashText = prefs.getString(HASH, null) ?: return false
        val salt = android.util.Base64.decode(saltText, android.util.Base64.NO_WRAP)
        val expected = android.util.Base64.decode(hashText, android.util.Base64.NO_WRAP)
        return MessageDigest.isEqual(expected, derive(pin, salt))
    }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun displayName(resolver: ContentResolver, uri: Uri): String {
        var name = "file"
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        return name.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120)
    }

    fun encryptIntoVault(resolver: ContentResolver, uri: Uri, name: String, vault: File): File {
        vault.mkdirs()
        val target = File(vault, "${java.util.UUID.randomUUID()}.vlt")
        val nonce = ByteArray(NONCE_SIZE).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey(), GCMParameterSpec(128, nonce))
        try {
            FileOutputStream(target).use { fileOut ->
                fileOut.write(nonce)
                CipherOutputStream(fileOut, cipher).use { encrypted ->
                    DataOutputStream(encrypted).use { data ->
                        data.writeUTF(name)
                        resolver.openInputStream(uri)?.use { input -> input.copyTo(data) }
                            ?: throw IOException("Impossibile leggere il file selezionato")
                    }
                }
            }
        } catch (e: Exception) {
            target.delete()
            throw e
        }
        return target
    }

    fun listNames(vault: File): List<Pair<File, String>> {
        vault.mkdirs()
        return vault.listFiles()?.filter { it.isFile && it.extension == "vlt" }?.mapNotNull { file ->
            runCatching { file to decryptName(file) }.getOrNull()
        }?.sortedBy { it.second.lowercase() } ?: emptyList()
    }

    private fun decryptName(file: File): String {
        FileInputStream(file).use { input ->
            val nonce = ByteArray(NONCE_SIZE)
            if (input.read(nonce) != NONCE_SIZE) throw IOException("File non valido")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, nonce))
            CipherInputStream(input, cipher).use { decrypted ->
                return DataInputStream(decrypted).use { it.readUTF() }
            }
        }
    }

    fun export(file: File, output: OutputStream) {
        FileInputStream(file).use { input ->
            val nonce = ByteArray(NONCE_SIZE)
            if (input.read(nonce) != NONCE_SIZE) throw IOException("File non valido")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, nonce))
            CipherInputStream(input, cipher).use { decrypted ->
                val data = DataInputStream(decrypted)
                data.readUTF()
                data.copyTo(output)
            }
        }
    }
}
