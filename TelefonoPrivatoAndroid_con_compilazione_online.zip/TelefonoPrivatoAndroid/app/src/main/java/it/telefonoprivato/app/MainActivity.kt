package it.telefonoprivato.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

private const val DEMO_PIN = "2580" // Cambiare prima di distribuire l'app.

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VaultApp(filesDir, contentResolver) }
    }
}

@Composable
private fun VaultApp(privateDir: File, resolver: android.content.ContentResolver) {
    var pin by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            runCatching {
                val folder = File(privateDir, "vault").apply { mkdirs() }
                val target = File(folder, "elemento_${System.currentTimeMillis()}")
                resolver.openInputStream(it)?.use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                }
                refresh++
            }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF16A765),
        background = Color.White,
        surface = Color.White
    )) {
        if (!unlocked) {
            DialerScreen(
                pin = pin,
                error = error,
                onDigit = { if (pin.length < 8) { pin += it; error = false } },
                onDelete = { if (pin.isNotEmpty()) pin = pin.dropLast(1) },
                onCall = {
                    if (pin == DEMO_PIN) { unlocked = true; error = false }
                    else { error = true; pin = "" }
                }
            )
        } else {
            VaultScreen(
                privateDir = privateDir,
                onBack = { unlocked = false; pin = "" },
                onPick = { picker.launch(arrayOf("*/*")) },
                refresh = refresh,
                onRefresh = { refresh++ }
            )
        }
    }
}

@Composable
private fun DialerScreen(
    pin: String, error: Boolean,
    onDigit: (String) -> Unit, onDelete: () -> Unit, onCall: () -> Unit
) {
    val keys = listOf("1","2","3","4","5","6","7","8","9","*","0","#")
    Column(
        modifier = Modifier.fillMaxSize().background(Color.White).padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(52.dp))
        Text("Telefono", color = Color(0xFF555555), fontSize = 17.sp)
        Spacer(Modifier.weight(1f))
        Text(if (pin.isEmpty()) " " else "• ".repeat(pin.length),
            fontSize = 27.sp, color = Color(0xFF222222))
        if (error) Text("Codice non corretto", color = Color.Red, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        for (row in keys.chunked(3)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { key ->
                    Box(
                        Modifier.size(76.dp).clickable { onDigit(key) },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(key, fontSize = 29.sp, color = Color(0xFF222222))
                            val letters = when (key) {
                                "2" -> "ABC"; "3" -> "DEF"; "4" -> "GHI"
                                "5" -> "JKL"; "6" -> "MNO"; "7" -> "PQRS"
                                "8" -> "TUV"; "9" -> "WXYZ"; else -> ""
                            }
                            Text(letters, fontSize = 9.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.size(58.dp))
            Box(
                Modifier.size(62.dp).background(Color(0xFF16A765), CircleShape)
                    .clickable { onCall() },
                contentAlignment = Alignment.Center
            ) { Text("☎", color = Color.White, fontSize = 27.sp) }
            Box(Modifier.size(58.dp).clickable { onDelete() }, contentAlignment = Alignment.Center) {
                Text("⌫", fontSize = 25.sp, color = Color.DarkGray)
            }
        }
        Spacer(Modifier.weight(1f))
        Text("Preferiti     Recenti     Contatti", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun VaultScreen(
    privateDir: File, onBack: () -> Unit, onPick: () -> Unit,
    refresh: Int, onRefresh: () -> Unit
) {
    val folder = remember { File(privateDir, "vault").apply { mkdirs() } }
    val files = remember(refresh) { folder.listFiles()?.toList() ?: emptyList() }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 26.sp, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(16.dp))
            Text("Cartella privata", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(8.dp))
        Text("I file salvati qui sono nella memoria privata dell'app.",
            color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) {
            Text("＋  Importa file")
        }
        Spacer(Modifier.height(14.dp))
        if (files.isEmpty()) {
            Text("La cartella è vuota.", color = Color.Gray)
        } else {
            LazyColumn {
                items(files, key = { it.name }) { file ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(file.name, modifier = Modifier.weight(1f), fontSize = 14.sp)
                        IconButton(onClick = { file.delete(); onRefresh() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Elimina")
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
