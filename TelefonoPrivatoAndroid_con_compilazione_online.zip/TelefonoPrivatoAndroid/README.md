# Telefono Privato — progetto Android iniziale

## Creare l'APK senza computer (usando GitHub dal Samsung)

1. Crea o accedi a un account su https://github.com
2. Crea un nuovo repository, ad esempio `TelefonoPrivato`.
3. Carica nel repository tutti i file contenuti in questo archivio (compresa la cartella nascosta `.github`).
4. Apri la scheda **Actions** del repository.
5. Se richiesto, abilita GitHub Actions.
6. Seleziona **Crea APK Android** e premi **Run workflow**.
7. Attendi che il workflow termini. Apri l'esecuzione completata e scarica l'elemento `TelefonoPrivato-APK`.
8. Estrai l'archivio scaricato e apri `app-debug.apk` sul Samsung per installarlo. Potrebbe essere necessario autorizzare temporaneamente l'installazione da quella sorgente nelle impostazioni Android.

## PIN demo
Il PIN iniziale è `2580`. È un valore dimostrativo nel codice (`DEMO_PIN` in `MainActivity.kt`):
va sostituito con una gestione sicura del PIN prima di un uso reale.

## Limiti importanti
- Questa è una base dimostrativa, non un'app pronta per la distribuzione.
- Android non permette a una normale app di nascondere o inglobare liberamente altre app installate. Questa base custodisce copie di file importati.
- I file sono copiati nella sandbox privata dell'app, ma questa versione non implementa cifratura, recupero PIN, protezione anti-manomissione o blocco automatico. Non usarla per dati sensibili finché non vengono aggiunte.
- L'app non effettua chiamate telefoniche.
